module BuddiesHelper
end
