class Buddy < ApplicationRecord
end
